/* W8D4_PROVA_FINALE_TASK2 DESCRIVI LA STRUTTURA DELLE TABELLE CHE REPUTI UTILI A SUFFICIENTI A MODELLARE LO SCENARIO PROPOSTO TRAMITE 
LA SINTASSI DDL. IMPLEMENTA FISICAMENTE LE TABELLE UTILIZZANDO IL DBMS SQL SERVER (o altro).*/

CREATE schema W8D4_SQL_PROVA_FINALE;
USE W8D4_SQL_PROVA_FINALE;

/* Si procede all'inserimento delle tabelle e delle Primary Key e Foreign key*/

create table CATEGORIA (
ID_CATEGORIA int
, CATEGORIA varchar(25) not NULL);

alter TABLE CATEGORIA
ADD constraint PK_CATEGORIA primary key (ID_CATEGORIA);

create table REGIONE (
ID_REGIONE int
, REGIONE varchar(25) not NULL);

alter TABLE REGIONE
ADD constraint PK_REGIONE primary key (ID_REGIONE);

create table PRODOTTO (
ID_PRODOTTO int
, NOME varchar(25)
, ID_CATEGORIA int NOT null);

alter TABLE PRODOTTO
ADD constraint PK_PRODOTTO primary key (ID_PRODOTTO)
, ADD constraint FK_ID_CATEGORIA_PRODOTTO foreign key (ID_CATEGORIA)
references categoria(ID_CATEGORIA);

create table STATO (
ID_STATO int
, STATO varchar(25)
, ID_REGIONE int NOT null);

alter TABLE STATO
ADD constraint PK_STATO primary key (ID_STATO)
, ADD constraint FK_ID_REGIONE_STATO foreign key (ID_REGIONE)
references regione(ID_REGIONE);

create table STORE (
ID_STORE int
, NOME varchar(25)
, ID_STATO int NOT null
, INDIRIZZO varchar(65));

alter TABLE STORE
ADD constraint PK_STORE primary key (ID_STORE)
, ADD constraint FK_ID_STATO_STORE foreign key (ID_STATO)
references STATO(ID_STATO);

create table VENDITA (
ID_ORDINE int
, DATA date NOT NULL
, ID_PRODOTTO int NOT NULL
, ID_STORE int NOT null
, QUANTITA INT NOT NULL
, IMPORTO DECIMAL (9,2));

alter TABLE vendita
ADD constraint PK_VENDITA primary key (ID_ORDINE)
, ADD constraint FK_ID_PRODOTTO_VENDITA foreign key (ID_PRODOTTO)
references prodotto(ID_PRODOTTO)
, ADD constraint FK_ID_STORE_VENDITA foreign key (ID_STORE)
references store(ID_STORE);

/* W8D4_PROVA_FINALE_TASK3 Popola le tabelle utilizzando dati a tua discrezione (sono sufficienti pochi record per tabella;
riporta le query utilizzate)*/

-- CATEGORIA --

insert into categoria values
(1,'Peluche')
,(2,'Bambole')
,(3,'Giochi da Tavolo')
,(4,'Puzzle')
,(5,'Giochi Prima Infanzia');

-- REGIONE --

insert into regione values
(1,'Europa Occidentale')
,(2,'Europa Orientale')
,(3,'America del Nord')
,(4,'America Centrale')
,(5,'America del Sud')
,(6,'Sud-Est-Asiatico')
,(7,'Medio oriente');

-- PRODOTTO --

insert into prodotto values
(1,'Orsetto',1)
,(2,'Doggye',1)
,(3,'Tiger',1)
,(4,'Dolly',2)
,(5,'Cicciobello',2)
,(6,'Barbie',2)
,(7,'Monopoli',3)
,(8,'Risiko',3)
,(9,'Domino',3)
,(10,'Torre Eifel',4)
,(11,'Ponte di Brooklin',4)
,(12,'La Venere',4)
,(13,'Tappeto Puzzle',5)
,(14,'Arca di Noe',5)
,(15,'Martino Cavallino',5);



INSERT INTO prodotto (ID_PRODOTTO,NOME,ID_CATEGORIA)
values (16,'La Fattoria',5);

-- STATO --

insert into stato values
(1,'Italia',1)
,(2,'Francia',1)
,(3,'Spagna',1)
,(4,'Germania',1)
,(5,'Romania',2)
,(6,'Bulgaria',2)
,(7,'U.S.A.',3)
,(8,'Canada',3)
,(9,'Messico',4)
,(10,'Brasile',5)
,(11,'Argentina',5)
,(12,'Vietnam',6)
,(13,'Thailandia',6)
,(14,'Libano',7)
,(15,'Israele',7);


-- STORE --

insert into store values
(1,'PV_ROMA',1,'Via del Corso 12, 00187')
,(2,'PV_MILANO',1,'Corso Buenos Aires 24, 20124')
,(3,'PV_PALERMO',1,'Via Vittorio Emanuele 212, 90134')
,(4,'PV_PARIGI',2,'Avenue des Champs-Élysées 44, 75008')
,(5,'PV_MADRID',3,'Calle de Alcalá 88, 28014')
,(6,'PV_FRANCOFORTE',4,'Kaiserstraße 34, 60311')
,(7,'PV_BERLINO',4,'Unter den Linden 22, 10117')
,(8,'PV_BUCAREST',5,'Bulevardul Unirii 12, 030167')
,(9,'PV_SOFIA',6,'Vitosha Boulevard 14, 1000')
,(10,'PV_NEW YORK',7,'5th Avenue, New York 24, NY 1000')
,(11,'PV_LOS ANGELES',7,'Sunset  Boulevard 212,  CA 90028')
,(12,'PV_TORONTO',8,'Yonge Street, Toronto 124, ON M4W 2H2')
,(13,'PV_CITTA DEL MESSICO',9,'Paseo de la Reforma 44, 06500')
,(14,'PV_RIO DE JANEIRO',10,'Avenida Atlântica124, Copacabana, 22021-001')
,(15,'PV_BUENOS AIRES',11,'Avenida 9 de Julio212, CABA')
,(16,'PV_HANOI',12,'Phi Ciu Gi Hoàn Kiim 16')
,(17,'PV_BANGKOK',13,'Sukhumvit Road Khlong Toei 246')
,(18,'PV_BEIRUT',14,'Rue Verdun 124')
,(19,'PV_GERUSALEMME',15,'Jaffa Road 12')
,(20,'PV_TEL AVIV',15,'Rothschild Boulevard 88');



-- VENDITA --

insert into vendita values

(1,'2023-09-20',1,9,1,10)
,(2,'2023-09-20',2,8,1,21)
,(3,'2023-09-20',3,2,1,18)
,(4,'2023-09-20',3,9,1,18)
,(5,'2023-09-20',4,2,1,25)
,(6,'2023-09-20',4,3,1,25)
,(7,'2023-09-20',5,1,1,28.5)
,(8,'2023-09-20',6,3,1,32)
,(9,'2023-09-20',6,7,1,32)
,(10,'2023-09-20',7,13,1,35)
,(11,'2023-09-20',7,3,1,35)
,(12,'2023-09-20',8,15,1,44.5)
,(13,'2023-09-20',8,3,1,44.5)
,(14,'2023-09-20',9,3,1,23.5)
,(15,'2023-09-20',9,3,1,23.5)
,(16,'2023-09-20',10,3,1,15)
,(17,'2023-09-20',10,18,1,15)
,(18,'2023-09-20',11,1,1,14)
,(19,'2023-09-20',12,3,1,13.5)
,(20,'2023-09-20',12,6,1,13.5)
,(21,'2023-09-20',12,12,1,13.5)
,(22,'2023-09-20',13,3,1,45.5)
,(23,'2023-09-20',13,6,1,45.5)
,(24,'2023-09-20',14,1,1,28)
,(25,'2023-09-20',15,1,1,12)
,(26,'2023-11-25',3,1,1,18)
,(27,'2023-11-25',4,2,1,25)
,(28,'2023-11-25',6,1,1,32)
,(29,'2023-11-25',6,15,1,32)
,(30,'2023-11-25',6,12,1,32)
,(31,'2023-11-25',7,3,1,35)
,(32,'2023-11-25',7,18,1,35)
,(33,'2023-11-25',8,3,1,44.5)
,(34,'2023-11-25',8,17,1,44.5)
,(35,'2023-11-25',9,12,1,23.5)
,(36,'2023-11-25',9,11,1,23.5)
,(37,'2023-11-25',11,3,1,14)
,(38,'2023-11-25',12,7,1,13.5)
,(39,'2023-11-25',14,5,1,28)
,(40,'2023-11-25',15,6,1,12)
,(41,'2024-03-14',1,1,1,10)
,(42,'2024-03-14',1,1,1,10)
,(43,'2024-03-14',1,12,1,10)
,(44,'2024-03-14',2,2,1,21)
,(45,'2024-03-14',2,14,1,21)
,(46,'2024-03-14',4,3,1,25)
,(47,'2024-03-14',4,10,1,25)
,(48,'2024-03-14',5,4,1,28.5)
,(49,'2024-03-14',5,9,1,28.5)
,(50,'2024-03-14',5,12,1,28.5)
,(51,'2024-03-14',6,3,1,32)
,(52,'2024-03-14',7,4,1,35)
,(53,'2024-03-14',7,20,1,35)
,(54,'2024-03-14',8,17,1,44.5)
,(55,'2024-03-14',9,12,1,23.5)
,(56,'2024-03-14',9,5,1,23.5)
,(57,'2024-03-14',9,16,1,23.5)
,(58,'2024-03-14',10,20,1,15)
,(59,'2024-03-14',10,15,1,15)
,(60,'2024-03-14',11,19,1,14)
,(61,'2024-03-14',11,7,1,14)
,(62,'2024-03-14',11,1,1,14)
,(63,'2024-03-14',12,18,1,13.5)
,(64,'2024-03-14',12,12,1,13.5)
,(65,'2024-03-14',12,11,1,13.5)
,(66,'2024-03-14',12,6,1,13.5)
,(67,'2024-03-14',12,20,1,13.5)
,(68,'2024-03-14',14,2,1,28)
,(69,'2024-03-14',15,17,1,12)
,(70,'2024-03-14',15,8,1,12)
,(71,'2024-04-06',1,11,1,10)
,(72,'2024-04-06',1,9,1,10)
,(73,'2024-04-06',1,9,1,10)
,(74,'2024-04-06',1,18,1,10)
,(75,'2024-04-06',2,7,1,21)
,(76,'2024-04-06',2,4,1,21)
,(77,'2024-04-06',3,10,1,18)
,(78,'2024-04-06',3,15,1,18)
,(79,'2024-04-06',5,11,1,28.5)
,(80,'2024-04-06',5,9,1,28.5)
,(81,'2024-04-06',6,1,1,32)
,(82,'2024-04-06',6,17,1,32)
,(83,'2024-04-06',7,1,1,35)
,(84,'2024-04-06',7,12,1,35)
,(85,'2024-04-06',8,11,1,44.5)
,(86,'2024-04-06',9,2,1,23.5)
,(87,'2024-04-06',9,2,1,23.5)
,(88,'2024-04-06',9,13,1,23.5)
,(89,'2024-04-06',10,1,1,15)
,(90,'2024-04-06',10,14,1,15)
,(91,'2024-04-06',11,1,1,14)
,(92,'2024-04-06',11,5,1,14)
,(93,'2024-04-06',11,3,1,14)
,(94,'2024-04-06',12,20,1,13.5)
,(95,'2024-04-06',12,19,1,13.5)
,(96,'2024-04-06',12,3,1,13.5)
,(97,'2024-04-06',14,3,1,28)
,(98,'2024-04-06',14,19,1,28)
,(99,'2024-04-06',14,2,1,28)
,(100,'2024-04-06',15,4,1,12)
,(101,'2024-05-10',1,5,1,10)
,(102,'2024-05-10',1,11,1,10)
,(103,'2024-05-10',1,1,1,10)
,(104,'2024-05-10',2,12,1,21)
,(105,'2024-05-10',2,20,1,21)
,(106,'2024-05-10',3,2,1,18)
,(107,'2024-05-10',3,14,1,18)
,(108,'2024-05-10',4,7,1,25)
,(109,'2024-05-10',5,1,1,28.5)
,(110,'2024-05-10',5,13,1,28.5)
,(111,'2024-05-10',6,7,1,32)
,(112,'2024-05-10',7,9,1,35)
,(113,'2024-05-10',7,8,1,35)
,(114,'2024-05-10',7,14,1,35)
,(115,'2024-05-10',8,20,1,44.5)
,(116,'2024-05-10',9,15,1,23.5)
,(117,'2024-05-10',9,9,1,23.5)
,(118,'2024-05-10',10,2,1,15)
,(119,'2024-05-10',11,19,1,14)
,(120,'2024-05-10',11,2,1,14)
,(121,'2024-05-10',11,10,1,14)
,(122,'2024-05-10',11,20,1,14)
,(123,'2024-05-10',12,3,1,13.5)
,(124,'2024-05-10',12,20,1,13.5)
,(125,'2024-05-10',12,3,1,13.5)
,(126,'2024-05-10',12,5,1,13.5)
,(127,'2024-05-10',12,1,1,13.5)
,(128,'2024-05-10',14,4,1,28)
,(129,'2024-05-10',14,12,1,28)
,(130,'2024-05-10',15,11,1,12)
,(131,'2024-07-10',1,10,1,10)
,(132,'2024-07-10',1,20,1,10)
,(133,'2024-07-10',1,13,1,10)
,(134,'2024-07-10',2,12,1,21)
,(135,'2024-07-10',3,19,1,18)
,(136,'2024-07-10',3,15,1,18)
,(137,'2024-07-10',4,3,1,25)
,(138,'2024-07-10',5,17,1,28.5)
,(139,'2024-07-10',5,1,1,28.5)
,(140,'2024-07-10',5,13,1,28.5)
,(141,'2024-07-10',6,2,1,32)
,(142,'2024-07-10',7,1,1,35)
,(143,'2024-07-10',8,16,1,44.5)
,(144,'2024-07-10',8,14,1,44.5)
,(145,'2024-07-10',9,15,1,23.5)
,(146,'2024-07-10',9,16,1,23.5)
,(147,'2024-07-10',9,5,1,23.5)
,(148,'2024-07-10',10,17,1,15)
,(149,'2024-07-10',10,18,1,15)
,(150,'2024-07-10',10,3,1,15)
,(151,'2024-07-10',11,19,1,14)
,(152,'2024-07-10',11,20,1,14)
,(153,'2024-07-10',11,7,1,14)
,(154,'2024-07-10',11,9,1,14)
,(155,'2024-07-10',12,1,1,13.5)
,(156,'2024-07-10',12,6,1,13.5)
,(157,'2024-07-10',12,2,1,13.5)
,(158,'2024-07-10',14,20,1,28)
,(159,'2024-07-10',15,1,1,12)
,(160,'2024-07-10',15,8,1,12)
,(161,'2024-09-20',1,19,1,10)
,(162,'2024-09-20',1,10,1,10)
,(163,'2024-09-20',1,20,1,10)
,(164,'2024-09-20',1,13,1,10)
,(165,'2024-09-20',1,1,1,10)
,(166,'2024-09-20',2,12,1,21)
,(167,'2024-09-20',2,15,1,21)
,(168,'2024-09-20',2,20,1,21)
,(169,'2024-09-20',5,1,1,28.5)
,(170,'2024-09-20',5,12,1,28.5)
,(171,'2024-09-20',6,2,1,32)
,(172,'2024-09-20',7,17,1,35)
,(173,'2024-09-20',7,1,1,35)
,(174,'2024-09-20',7,14,1,35)
,(175,'2024-09-20',9,16,1,23.5)
,(176,'2024-09-20',9,15,1,23.5)
,(177,'2024-09-20',9,16,1,23.5)
,(178,'2024-09-20',9,5,1,23.5)
,(179,'2024-09-20',10,17,1,15)
,(180,'2024-09-20',10,11,1,15)
,(181,'2024-09-20',11,18,1,14)
,(182,'2024-09-20',11,7,1,14)
,(183,'2024-09-20',12,3,1,13.5)
,(184,'2024-09-20',12,1,1,13.5)
,(185,'2024-09-20',12,6,1,13.5)
,(186,'2024-09-20',13,9,1,45.5)
,(187,'2024-09-20',14,19,1,28)
,(188,'2024-09-20',14,3,1,28)
,(189,'2024-09-20',14,8,1,28)
,(190,'2024-09-20',14,20,1,28)
,(191,'2024-10-20',1,1,1,10)
,(192,'2024-10-20',1,7,1,10)
,(193,'2024-10-20',1,1,1,10)
,(194,'2024-10-20',1,14,1,10)
,(195,'2024-10-20',2,10,1,21)
,(196,'2024-10-20',2,13,1,21)
,(197,'2024-10-20',3,20,1,18)
,(198,'2024-10-20',3,4,1,18)
,(199,'2024-10-20',3,11,1,18)
,(200,'2024-10-20',4,8,1,25)
,(201,'2024-10-20',5,3,1,28.5)
,(202,'2024-10-20',6,19,1,32)
,(203,'2024-10-20',6,10,1,32)
,(204,'2024-10-20',7,9,1,35)
,(205,'2024-10-20',7,17,1,35)
,(206,'2024-10-20',7,20,1,35)
,(207,'2024-10-20',8,15,1,44.5)
,(208,'2024-10-20',8,2,1,44.5)
,(209,'2024-10-20',9,19,1,23.5)
,(210,'2024-10-20',9,20,1,23.5)
,(211,'2024-10-20',9,16,1,23.5)
,(212,'2024-10-20',10,20,1,15)
,(213,'2024-10-20',11,12,1,14)
,(214,'2024-10-20',11,16,1,14)
,(215,'2024-10-20',11,19,1,14)
,(216,'2024-10-20',12,5,1,13.5)
,(217,'2024-10-20',12,2,1,13.5)
,(218,'2024-10-20',12,15,1,13.5)
,(219,'2024-10-20',12,12,1,13.5)
,(220,'2024-10-20',15,20,1,12)
,(221,'2024-10-25',1,7,1,10)
,(222,'2024-10-25',1,20,1,10)
,(223,'2024-10-25',1,19,1,10)
,(224,'2024-10-25',2,9,1,21)
,(225,'2024-10-25',2,17,1,21)
,(226,'2024-10-25',3,6,1,18)
,(227,'2024-10-25',3,8,1,18)
,(228,'2024-10-25',3,16,1,18)
,(229,'2024-10-25',3,18,1,18)
,(230,'2024-10-25',3,20,1,18)
,(231,'2024-10-25',4,2,1,25)
,(232,'2024-10-25',5,3,1,28.5)
,(233,'2024-10-25',6,14,1,32)
,(234,'2024-10-25',7,1,1,35)
,(235,'2024-10-25',7,13,1,35)
,(236,'2024-10-25',8,5,1,44.5)
,(237,'2024-10-25',8,16,1,44.5)
,(238,'2024-10-25',9,7,1,23.5)
,(239,'2024-10-25',9,15,1,23.5)
,(240,'2024-10-25',10,4,1,15)
,(241,'2024-10-25',10,5,1,15)
,(242,'2024-10-25',10,12,1,15)
,(243,'2024-10-25',10,13,1,15)
,(244,'2024-10-25',11,1,1,14)
,(245,'2024-10-25',11,15,1,14)
,(246,'2024-10-25',12,12,1,13.5)
,(247,'2024-10-25',13,20,1,45.5)
,(248,'2024-10-25',14,2,1,28)
,(249,'2024-10-25',14,10,1,28)
,(250,'2024-10-25',15,14,1,12)



/* W8D4_PROVA_FINALE_TASK4 "DOPO AVER POPOLATO LE TABELLE, SCRIVI LE QUERY*/
/*1) Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare l'univocità dei valori di 
ciascuna PK (una query per tabella implementata).*/

/* PER DIMOSTRARE CHE LE ID INSERITE COME PRIMARIE SONO POPOLATI CON VALORI UNIVOCI HO SCELTO DI RAGGRUPARE LE PK E DI CONTARE IL NUMERO DI VOLTE 
PER CUI SI RIPETONO. OVVIAMENTE SE SONO UNIVOCHE LA QUERY DEVE RESTITUIRE IL VALORE 1 PER TUTTI I CAMPI. PER MEGLIO VISUALIZZARE IL 
RISULTATO HO ORDINATO IL CONTEGGIO IN MODO DECRESCENTE*/

SELECT 
    ID_CATEGORIA, COUNT(ID_CATEGORIA) AS NUMERO_RIPETIZIONI_ID
FROM
    categoria
GROUP BY ID_CATEGORIA
ORDER BY COUNT(ID_CATEGORIA) DESC;

SELECT 
    ID_PRODOTTO, COUNT(ID_PRODOTTO) AS NUMERO_RIPETIZIONI_ID
FROM
    PRODOTTO
GROUP BY ID_PRODOTTO
ORDER BY COUNT(ID_PRODOTTO) DESC;

SELECT 
    ID_REGIONE, COUNT(ID_REGIONE) AS NUMERO_RIPETIZIONI_ID
FROM
    REGIONE
GROUP BY ID_REGIONE
ORDER BY COUNT(ID_REGIONE) DESC;

SELECT 
    ID_STATO, COUNT(ID_STATO) AS NUMERO_RIPETIZIONI_ID
FROM
    STATO
GROUP BY ID_STATO
ORDER BY COUNT(ID_STATO) DESC;

SELECT 
    ID_STORE, COUNT(ID_STORE) AS NUMERO_RIPETIZIONI_ID
FROM
    STORE
GROUP BY ID_STORE
ORDER BY COUNT(ID_STORE) DESC;

SELECT 
    ID_ORDINE, COUNT(ID_ORDINE) AS NUMERO_RIPETIZIONI_ID
FROM
    VENDITA
GROUP BY ID_ORDINE
ORDER BY COUNT(ID_ORDINE) DESC;


/* W8D4_PROVA_FINALE_TASK4 "DOPO AVER POPOLATO LE TABELLE, SCRIVI LE QUERY*/
/*2) Esporre l'elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, 
il nome dello stato, il nome della regione di vendita e un campo boleano valorizzato in base alla condizione che siano passati più di 180 
giorni dalla data di vendita o meno (<180 --> true >180 --> False)*/
/* .... Ho fatto delle Inner Join tra le diverse tabelle dello schema per avere tutti i dati che mi servono. Le inner mi restituiscono esattamente
le 250 righe di della tabella vendite. Con un 'Case when verifichiamo la condizione della vendita > 180 gg.) */

SELECT 
    ID_ORDINE,
    DATA,
    p.NOME,
    c.CATEGORIA,
    s.STATO,
    r.REGIONE,
    CASE
        WHEN DATEDIFF(CURRENT_DATE, data) > 180 THEN 'vero'
        ELSE 'falso'
    END AS '>180_Giorni'
FROM
    vendita v
        INNER JOIN
    prodotto p ON v.ID_PRODOTTO = p.ID_PRODOTTO
        INNER JOIN
    categoria c ON p.ID_CATEGORIA = c.ID_CATEGORIA
        INNER JOIN
    store pv ON v.ID_STORE = pv.ID_STORE
        INNER JOIN
    stato s ON pv.ID_StATO = s.ID_STATO
        INNER JOIN
    regione r ON s.ID_REGIONE = r.ID_REGIONE;


/* W8D4_PROVA_FINALE_TASK4 "DOPO AVER POPOLATO LE TABELLE, SCRIVI LE QUERY*/
/*3) Esporre l'elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell'ultimo 
anno censito, (ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). Nel result set devono comparire 
solo il codice prodotto e il totale venduto.*/
/* Data la condizione specifica che ad ogni ordine corrispone una singola vendita ... la media complessiva non è altro che il rapporto 
tra il numero totale degli ordine / il numero di prodotti - ordini opportumanete filtrati di 1 anno. Ho fatto una subquery indipendente
scalare per calcolarmi questo valore --- soluzione generalizzante nel caso in cui il singolo ordine possa prevedere più di 1 quantità 
venduta. Dunque ho utilizzato questa subquery come condizione per espormi solo quei raggruppamenti di prodotto la cui quantità venduta
sia maggiore del valore risultante dalla query scalare ... usandola nella having...Le vendite considerate infine sono solo quelle aventi data 
antecedenet alla attuale di non più di 1 anno*/

/* questa sottoindicata è la subquery...*/

SELECT 
    AVG(x.quantità_vendute) AS Media
FROM
    (SELECT 
        p.ID_PRODOTTO, SUM(QUANTITA) quantità_vendute, p.NOME
    FROM
        vendita v
    INNER JOIN prodotto p ON v.ID_PRODOTTO = p.ID_PRODOTTO
    WHERE
        DATA > CURDATE() - INTERVAL 1 YEAR
    GROUP BY p.ID_PRODOTTO) AS x;


/* questa sottoindicata è la query definitiva...*/
SELECT 
    p.ID_PRODOTTO, SUM(QUANTITA) quantità_vendute, p.NOME
FROM
    vendita v
        INNER JOIN
    prodotto p ON v.ID_PRODOTTO = p.ID_PRODOTTO
WHERE
    DATA > CURDATE() - INTERVAL 1 YEAR
GROUP BY p.ID_PRODOTTO
HAVING SUM(QUANTITA) > (SELECT 
        AVG(x.quantità_vendute) AS Media
    FROM
        (SELECT 
            p.ID_PRODOTTO, SUM(QUANTITA) quantità_vendute, p.NOME
        FROM
            vendita v
        INNER JOIN prodotto p ON v.ID_PRODOTTO = p.ID_PRODOTTO
        WHERE
            DATA > CURDATE() - INTERVAL 1 YEAR
        GROUP BY p.ID_PRODOTTO) AS x);

/* W8D4_PROVA_FINALE_TASK4 "DOPO AVER POPOLATO LE TABELLE, SCRIVI LE QUERY*/
/*4) Esporre l'elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.
ATTRAVERSO UNA SUBQUERY INDIPENDENTE MULTIPLA MI RICAVO I VALORI DELLE VENDITE SUDDIVISI PER ID_PRODOTTO ED ANNO,
INNESTO QUESTA QUERY COME SUBQUERY PER AGGREGARMI PER OGNI SINGOLO ANNO LE VENDITE PER CIASCUN PRODOTTO */

/*QUI SOTTO LA SUBQUERY AUTONOMA - MULTIPLA - */ 

SELECT 
    p.ID_PRODOTTO,
    p.nome,
    YEAR(DATA),
    SUM(V.IMPORTO) AS TOTALE_VENDITA
FROM
    prodotto p
        INNER JOIN
    vendita v ON p.ID_PRODOTTO = v.ID_PRODOTTO
GROUP BY ID_PRODOTTO , DATA;

/*QUI SOTTO LA QUERY DEFINITIVA- */ 
SELECT 
    Y.ID_PRODOTTO,
    Y.NOME,
    Y.ANNO,
    SUM(Y.TOTALE_VENDITA) AS VENDUTO_ANNO
FROM
    (SELECT 
        p.ID_PRODOTTO,
            p.nome,
            YEAR(DATA) AS ANNO,
            SUM(IMPORTO) AS TOTALE_VENDITA
    FROM
        prodotto p
    INNER JOIN vendita v ON p.ID_PRODOTTO = v.ID_PRODOTTO
    GROUP BY ID_PRODOTTO , DATA) AS Y
GROUP BY ID_PRODOTTO , ANNO;

/* W8D4_PROVA_FINALE_TASK4 "DOPO AVER POPOLATO LE TABELLE, SCRIVI LE QUERY*/
/*5) Esporre il fatturato totale per Stato e per Anno. Ordina il risultato per data e per fatturato decrescente.*/
/* Attraverso delle Inner Join metto insieme tutti i dati necessari alla analisi.. con group by per stato e per anno ho la 
possibilità di sommare il fatturato per questi raggruppamenti. Dunque espongo i dati per anno decrescente (quindi 2024...)
partendo dal fatturato maggiore realizzato in quell'anno da ogni singolo Stato*/ 

SELECT 
    s.ID_STATO,
    S.STATO,
    YEAR(V.DATA) ANNO,
    SUM(IMPORTO) AS TOTALE_VENDITE
FROM
    vendita v
        INNER JOIN
    store pv ON v.ID_STORE = pv.ID_STORE
        INNER JOIN
    stato s ON pv.ID_STATO = s.ID_STATO
GROUP BY ID_STATO , YEAR(V.DATA) , S.STATO
ORDER BY ANNO DESC , TOTALE_VENDITE DESC;


/* W8D4_PROVA_FINALE_TASK4 "DOPO AVER POPOLATO LE TABELLE, SCRIVI LE QUERY*/
/*6) Rispondere alla seguente domanda; qual'è la categoria di articoli maggiormente richiesta dal mercato?*/

SELECT 
    c.ID_CATEGORIA, c.CATEGORIA, SUM(QUANTITA) Articoli_Venduti
FROM
    vendita v
        INNER JOIN
    prodotto p ON v.ID_PRODOTTO = p.ID_PRODOTTO
        INNER JOIN
    categoria c ON p.ID_CATEGORIA = c.ID_CATEGORIA
GROUP BY c.ID_CATEGORIA , c.CATEGORIA
ORDER BY Articoli_Venduti DESC;

/*7) Rispondere alla seguente domanda; quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti*/

select*
from prodotto p
left join vendita v
on p.ID_PRODOTTO=v.ID_PRODOTTO
where ID_ORDINE is null;

select
p.ID_PRODOTTO
, p.NOME
, count(ID_ORDINE) Numero_Ordini
from prodotto p
left join vendita v
on p.ID_PRODOTTO=v.ID_PRODOTTO
group by p.ID_PRODOTTO
having count(ID_ORDINE) = 0;


/*8) Creare una vista sui prodotti in modo tale da esporre una "versione denormalizzata" delle informazioni utili
(Codice Prodotto, nome prodotto, nome categoria)*/

create view GV_VIEW_W8D4_PRODOTTO AS
select
P.ID_PRODOTTO
, P.NOME
, P.ID_CATEGORIA
, C.CATEGORIA
from prodotto p
inner join categoria c
on p.ID_CATEGORIA=c.ID_CATEGORIA;

create view GV_VIEW_W8D4_INFO_GEO AS
select
PV.ID_STORE
, PV.NOME
, PV.ID_STATO
, PV.INDIRIZZO
, S.STATO
, S.ID_REGIONE
, R.REGIONE
from store pv
inner join stato s
on pv.ID_STATO=s.ID_STATO
inner join regione r
on s.ID_REGIONE=r.ID_REGIONE